/**
 * Main program for managing an ordered list of cars.
 *
 * CSC 1351 Programming Project No 01
 * Section 002
 *
 * @author Cameron Sevin
 * @since 2024-03-17
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Prog01_aOrderedList {

    /**
     * Main method to execute the program.
     *
     * CSC 1351 Programming Project No 01
     * Section 002
     *
     * @param args Command-line arguments (not used)
     */
    public static void main(String[] args) {
        aOrderedList orderedList = new aOrderedList();

        try {
            Scanner scanner = GetInputFile("Enter input filename: ");
            PrintWriter writer = GetOutputFile("Enter output filename: ");
            int numCars = 0;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                if (parts[0].trim().equals("A")) {
                    String make = parts[1].trim();
                    int year = Integer.parseInt(parts[2].trim());
                    int price = Integer.parseInt(parts[3].trim());
                    Car car = new Car(make, year, price);
                    orderedList.add(car);
                    numCars++;
                } else if (parts[0].trim().equals("D")) {
                    String make = parts[1].trim();
                    int year = Integer.parseInt(parts[2].trim());
                    orderedList.remove(make, year);
                    numCars--;
                }
            }
            scanner.close();

            writer.println("Number of cars: " + numCars);
            orderedList.reset();
            while (orderedList.hasNext()) {
                Car car = (Car) orderedList.next();
                writer.println();
                writer.println("Make: " + car.getMake());
                writer.println("Year: " + car.getYear());
                writer.println("Price: $" + car.getPrice());
            }
            writer.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Program execution canceled.");
        }
    }

    /**
     * Prompts the user for the filename of a text input file and returns a Scanner object ready for input.
     *
     * CSC 1351 Programming Project No 01
     * Section 002
     *
     * @param userPrompt The prompt to display to the user
     * @return A Scanner object ready for input
     * @throws FileNotFoundException If the specified file is not found
     */
    public static Scanner GetInputFile(String userPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        boolean validFile = false;
        File inputFile = null;

        do {
            System.out.print(userPrompt);
            String filename = scanner.nextLine().trim();
            inputFile = new File(filename);
            if (inputFile.exists()) {
                validFile = true;
            } else {
                System.out.println("File specified <" + filename + "> does not exist. Would you like to continue? <Y/N>");
                String choice = scanner.nextLine().trim();
                if (!choice.equalsIgnoreCase("Y")) {
                    throw new FileNotFoundException();
                }
            }
        } while (!validFile);

        return new Scanner(inputFile);
    }

    /**
     * Prompts the user for the filename of a text output file and returns a PrintWriter object ready for output.
     *
     * CSC 1351 Programming Project No 01
     * Section 002
     *
     * @param userPrompt The prompt to display to the user
     * @return A PrintWriter object ready for output
     * @throws FileNotFoundException If the specified file is not found or cannot be created
     */
    public static PrintWriter GetOutputFile(String userPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        PrintWriter writer = null;
        boolean validFile = false;

        do {
            System.out.print(userPrompt);
            String filename = scanner.nextLine().trim();
            File outputFile = new File(filename);
            try {
                writer = new PrintWriter(outputFile);
                validFile = true;
            } catch (FileNotFoundException e) {
                System.out.println("Invalid filename or insufficient permissions. Would you like to continue? <Y/N>");
                String choice = scanner.nextLine().trim();
                if (!choice.equalsIgnoreCase("Y")) {
                    throw new FileNotFoundException();
                }
            }
        } while (!validFile);

        return writer;
    }
}
