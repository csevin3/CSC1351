/**
 * Represents a car with make, year, and price attributes..
 *
 * CSC 1351 Programming Project No 01
 * Section 002
 *
 * @author Cameron Sevin
 * @since 2024-03-17
 */

public class Car implements Comparable<Car> {
    // Private Members
    private String make; // The make of the car
    private int year; // The year the car was manufactured
    private int price; // The price of the car
    
    /**
     * Constructor for creating a new Car object.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @param make The make of the car
     * @param year The year the car was manufactured
     * @param price The price of the car
     */
    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }
    
    /**
     * Returns the make of the car.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @return The make of the car
     */
    public String getMake() {
        return make;
    }
    
    /**
     * Returns the year the car was manufactured.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @return The year the car was manufactured
     */
    public int getYear() {
        return year;
    }
    
    /**
     * Returns the price of the car.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @return The price of the car
     */
    public int getPrice() {
        return price;
    }
    
    /**
     * Compares this car with another car based on make and year.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @param other The other car to compare with
     * @return A negative integer, zero, or a positive integer as this car is less than, equal to, or greater than the specified car
     */
    @Override
    public int compareTo(Car other) {
        if (!make.equals(other.make)) {
            return make.compareTo(other.make);
        } else {
            return Integer.compare(year, other.year);
        }
    }
    
    /**
     * Returns a string representation of the car.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @return A string representation of the car
     */
    @Override
    public String toString() {
        return "Make: " + make + ", Year: " + year + ", Price: " + price;
    }
}