/**
 * Represents an ordered list of comparable objects.
 *
 * CSC 1351 Programming Project No 01
 * Section 002
 *
 * @author Cameron Sevin
 * @since 2024-03-17
 */

import java.util.Arrays;

public class aOrderedList {
    // Private Members
    private Comparable[] oList; // The ordered list
    private int listSize; // The size of the ordered list
    private int numObjects; // The number of objects in the ordered list
    private int curr; // Index of current element accessed via iterator methods
    
    /**
     * Constructor for creating a new aOrderedList object.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     */
    public aOrderedList() {
        numObjects = 0;
        listSize = 20; // Initial size of the list
        oList = new Comparable[listSize];
        curr = -1; // Initialize current index
    }
    
    /**
     * Adds a new object to the ordered list.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @param newObject The object to add
     */
    public void add(Comparable newObject) {
        if (numObjects == listSize) {
            increaseSize();
        }
        
        int insertIndex = 0;
        while (insertIndex < numObjects && oList[insertIndex].compareTo(newObject) < 0) {
            insertIndex++;
        }
        
        // Shift elements to make space for newObject
        for (int i = numObjects; i > insertIndex; i--) {
            oList[i] = oList[i - 1];
        }
        
        oList[insertIndex] = newObject;
        numObjects++;
    }
    
    /**
     * Returns the element at the specified position in the list.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @param index The index of the element to return
     * @return The element at the specified position in the list
     */
    public Comparable get(int index) {
        if (index < 0 || index >= numObjects) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        return oList[index];
    }
    
    /**
     * Resets iterator parameters.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     */
    public void reset() {
        curr = -1;
    }
    
    /**
     * Returns the next element in the iteration and increments the iterator parameters.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @return The next element in the iteration
     */
    public Comparable next() {
        curr++;
        return oList[curr];
    }
    
    /**
     * Returns true if the iteration has more elements to iterate through.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @return True if the iteration has more elements; otherwise, false
     */
    public boolean hasNext() {
        return curr < numObjects - 1;
    }
    
    /**
     * Removes the last element returned by the next() method.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     */
    public void remove() {
        for (int i = curr; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
        numObjects--;
        curr--;
    }
    
    /**
     * Removes the first occurrence of the specified make and year from the list.
     *
     * CSC 1351 Programming Project No 01
     * Section 001
     *
     * @param make The make of the car to remove
     * @param year The year of the car to remove
     */
    public void remove(String make, int year) {
        for (int i = 0; i < numObjects; i++) {
            Car car = (Car) oList[i];
            if (car.getMake().equals(make) && car.getYear() == year) {
                for (int j = i; j < numObjects - 1; j++) {
                    oList[j] = oList[j + 1];
                }
                numObjects--;
                return;
            }
        }
    }
    
    // Private method to increase the size of the list
    private void increaseSize() {
        listSize += 20;
        oList = Arrays.copyOf(oList, listSize);
    }
}